default_app_config = 'college.apps.CollegeConfig'

